import sys

# "Training": Count occurrences of 'good'
with open(sys.argv[1], 'r') as f_in, open(sys.argv[2], 'w') as f_out:
    content = f_in.read()
    score = content.count('good')
    f_out.write(f"sentiment_score:{score}")
print(f"Trained model based on {sys.argv[1]} -> {sys.argv[2]}")

