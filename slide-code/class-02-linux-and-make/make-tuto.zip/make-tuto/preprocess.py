import sys

# Simple NLP: Lowercase and remove punctuation
with open(sys.argv[1], 'r') as f_in, open(sys.argv[2], 'w') as f_out:
    text = f_in.read()
    f_out.write(text.lower().replace('.', ''))
print(f"Preprocessed {sys.argv[1]} -> {sys.argv[2]}")

