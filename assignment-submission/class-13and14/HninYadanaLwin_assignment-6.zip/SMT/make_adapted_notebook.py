import json

notebook = {
    "cells": [],
    "metadata": {},
    "nbformat": 4,
    "nbformat_minor": 5
}

def add_md(text):
    notebook["cells"].append({
        "cell_type": "markdown",
        "metadata": {},
        "source": [line + "\n" for line in text.split("\n")]
    })

def add_code(text):
    notebook["cells"].append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [line + "\n" for line in text.split("\n")]
    })

add_md("# Grapheme-to-Phoneme SMT Pipeline (Adapted to Current Server Structure)\n\nThis notebook has been adapted to perfectly match the file structure you already have on your server, without you needing to move any files.")

add_md("## Step 1: Convert Test Data to SGML\nMoses EMS requires the evaluation (test) data to be wrapped in XML/SGML format. We use the perl scripts in your `clean-data/scripts` folder to process the data from your `data/` folder.")
add_code("%%bash\ncd /workspace/Kris/NLP/SMT\nmkdir -p pbsmt/test-sgm\n\nperl clean-data/scripts/src2sgm.pl data/test.my > pbsmt/test-sgm/test.my.src.sgm\nperl clean-data/scripts/ref2sgm.pl data/test.ph > pbsmt/test-sgm/test.ph.ref.sgm\necho 'SGML files generated successfully in pbsmt/test-sgm!'")

add_md("## Step 2: Overwrite the broken EMS config\nWe need to overwrite the old `pbsmt/config.baseline` so that it uses `.my` and `.ph`, points to the compiled root `mosesdecoder`, and uses the `data` folder.")
add_code("%%bash\ncat << 'CONFIG_EOF' > /workspace/Kris/NLP/SMT/pbsmt/config.baseline\ninput-extension = my\noutput-extension = ph\n\nmoses-src-dir = /workspace/Kris/NLP/SMT/mosesdecoder\nmoses-bin-dir = $moses-src-dir/bin\nmoses-script-dir = $moses-src-dir/scripts\nexternal-bin-dir = /workspace/Kris/NLP/SMT/tools\n\nmyrk-data = /workspace/Kris/NLP/SMT/data\n\ndecoder = $moses-bin-dir/moses\nlmplz = $moses-bin-dir/lmplz\nlm-binarizer = $moses-bin-dir/build_binary\ntype = 8\ngeneric-parallelizer = $moses-script-dir/ems/support/generic-parallelizer.perl\n\n[CORPUS:myrk]\nraw-stem = $myrk-data/train\nmax-sentence-length = 80\n\n[LM:myrk]\nraw-corpus = $myrk-data/train.$output-extension\nlm-training = \"$moses-script-dir/ems/support/lmplz-wrapper.perl -bin $moses-bin-dir/lmplz\"\nsettings = \"--prune '0 0 1' -T $working-dir/lm -S 20% --discount_fallback\" \norder = 5\n\n[INTERPOLATED-LM]\n\n[TRAINING]\nscript = $moses-script-dir/training/train-model.perl\nalignment-heuristic = grow-diag-final-and\n\n[TUNING]\nraw-input = $myrk-data/dev.$input-extension\nraw-reference = $myrk-data/dev.$output-extension\n\n[EVALUATION:test]\ninput-sgm = /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.$input-extension.src.sgm\nreference-sgm = /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.$output-extension.ref.sgm\nCONFIG_EOF\necho 'pbsmt/config.baseline successfully updated!'")

add_md("## Step 3: Overwrite and Run generate_configs.pl\nWe will update the generator script in your `pbsmt/` folder to scan the `data/` folder, then run it to create the final `my-ph` config.")
add_code("%%bash\ncat << 'GEN_EOF' > /workspace/Kris/NLP/SMT/pbsmt/generate_configs.pl\n#!/usr/bin/perl\nuse strict;\nmy @langs;\nmy $smtpath = \"/workspace/Kris/NLP/SMT/pbsmt\";\n\nforeach my $trainFile ( </workspace/Kris/NLP/SMT/data/train.*> ) {\n    $trainFile =~ m/train\\.([a-z]+)/;\n    push @langs, $1;\n}\n\nforeach my $expt (qw/baseline/) {\n    die(\"$smtpath/$expt already exists! Delete it first.\") if (-d \"$smtpath/$expt\");\n    `mkdir -p $smtpath/$expt`;\n    foreach my $src (@langs) {\n        foreach my $trg (@langs) {\n            next if $src eq $trg;\n            my $pair = \"${src}-${trg}\";\n            my $configFile = \"$smtpath/$expt/$pair/config.${expt}.$pair\";\n            `mkdir -p $smtpath/$expt/$pair`;\n            open FILE, \">$configFile\" or die;\n            print FILE \"# Config file for $pair ($expt)\\n\\n[GENERAL]\\n\";\n            print FILE \"working-dir = $smtpath/$expt/$pair\\n\";\n            print FILE \"input-extension = ${src}\\noutput-extension = ${trg}\\npair-extension = ${pair}\\n\\n\";\n            close FILE;\n            \n            `cat $configFile /workspace/Kris/NLP/SMT/pbsmt/config.baseline > tmp`;\n            `mv tmp $configFile`;\n        }\n    }\n}\nGEN_EOF\n\ncd /workspace/Kris/NLP/SMT/pbsmt\nrm -rf baseline\nperl generate_configs.pl\necho 'Configs generated successfully in pbsmt/baseline!'")

add_md("## Step 4: Run the Baseline Pipeline!\nThis kicks off the Moses Experiment Management System using the fully corrected configuration.")
add_code("%%bash\ncd /workspace/Kris/NLP/SMT/pbsmt/baseline/my-ph\n/workspace/Kris/NLP/SMT/mosesdecoder/scripts/ems/experiment.perl -config config.baseline.my-ph -exec -no-graph 2>&1 | tee -a run1.log")

with open("SMT_G2P_Adapted.ipynb", "w") as f:
    json.dump(notebook, f, indent=2)

print("Notebook SMT_G2P_Adapted.ipynb created successfully!")
