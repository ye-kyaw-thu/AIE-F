import json

notebook = {
    "cells": [],
    "metadata": {},
    "nbformat": 4,
    "nbformat_minor": 5
}

def add_md(text):
    notebook["cells"].append({
        "cell_type": "markdown",
        "metadata": {},
        "source": [line + "\n" for line in text.split("\n")]
    })

def add_code(text):
    notebook["cells"].append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [line + "\n" for line in text.split("\n")]
    })

add_md("# Grapheme-to-Phoneme SMT Pipeline (Moses EMS)\n\nThis notebook provides a clean, step-by-step pipeline to run your Grapheme-to-Phoneme translation task on a Linux server using the Moses Experiment Management System (EMS). \n\n**Server Path:** `/workspace/Kris/NLP/SMT/`")

add_md("## Step 1: Set up the Directory Structure\nLet's define our base paths and create the necessary folders.")
add_code("import os\n\nBASE_DIR = '/workspace/Kris/NLP/SMT'\nDATA_DIR = os.path.join(BASE_DIR, 'data')\nCLEAN_DATA_DIR = os.path.join(BASE_DIR, 'clean-data')\nPBSMT_DIR = os.path.join(BASE_DIR, 'pbsmt')\nSCRIPTS_DIR = os.path.join(BASE_DIR, 'scripts')\nTOOLS_DIR = os.path.join(BASE_DIR, 'tools')\n\nfor d in [BASE_DIR, DATA_DIR, CLEAN_DATA_DIR, PBSMT_DIR, SCRIPTS_DIR, TOOLS_DIR]:\n    os.makedirs(d, exist_ok=True)\n\nprint('Directories created successfully!')")

add_md("## Step 2: Clone and Compile Moses\nMoses needs to be compiled from source. This process will take some time.")
add_code("%%bash\ncd /workspace/Kris/NLP/SMT\ngit clone https://github.com/moses-smt/mosesdecoder.git\ncd mosesdecoder\n# Compile Moses with 4 cores\n./bjam -j4")

add_md("## Step 3: Clone and Compile GIZA++\nGIZA++ handles the word/character alignment.")
add_code("%%bash\ncd /workspace/Kris/NLP/SMT\ngit clone https://github.com/moses-smt/giza-pp.git\ncd giza-pp\nmake\n\n# Copy the required binaries to our tools folder\ncp GIZA++-v2/GIZA++ ../tools/\ncp GIZA++-v2/snt2cooc.out ../tools/\ncp mkcls-v2/mkcls ../tools/\necho 'GIZA++ compiled and tools copied!'")

add_md("## Step 4: Convert Test Data to SGML\nMoses EMS requires the evaluation (test) data to be wrapped in XML/SGML format. We use the perl scripts for this.\n*Make sure your `src2sgm.pl` and `ref2sgm.pl` are uploaded to the `scripts/` directory!*")
add_code("%%bash\ncd /workspace/Kris/NLP/SMT\nmkdir -p pbsmt/test-sgm\n\n# Assuming your data is named test.my (source) and test.ph (target)\nperl scripts/src2sgm.pl data/test.my > pbsmt/test-sgm/test.my.src.sgm\nperl scripts/ref2sgm.pl data/test.ph > pbsmt/test-sgm/test.ph.ref.sgm\necho 'SGML files generated!'")

add_md("## Step 5: Configure the baseline EMS file\nLet's generate the `config.baseline` file. This tells EMS where all your tools and data are.")
add_code("%%bash\ncat << 'CONFIG_EOF' > /workspace/Kris/NLP/SMT/scripts/config.baseline\ninput-extension = my\noutput-extension = ph\n\nmoses-src-dir = /workspace/Kris/NLP/SMT/mosesdecoder\nmoses-bin-dir = $moses-src-dir/bin\nmoses-script-dir = $moses-src-dir/scripts\nexternal-bin-dir = /workspace/Kris/NLP/SMT/tools\n\nmyrk-data = /workspace/Kris/NLP/SMT/data\n\ndecoder = $moses-bin-dir/moses\nlmplz = $moses-bin-dir/lmplz\nlm-binarizer = $moses-bin-dir/build_binary\ntype = 8\ngeneric-parallelizer = $moses-script-dir/ems/support/generic-parallelizer.perl\n\n[CORPUS:myrk]\nraw-stem = $myrk-data/train\nmax-sentence-length = 80\n\n[LM:myrk]\nraw-corpus = $myrk-data/train.$output-extension\nlm-training = \"$moses-script-dir/ems/support/lmplz-wrapper.perl -bin $moses-bin-dir/lmplz\"\nsettings = \"--prune '0 0 1' -T $working-dir/lm -S 20% --discount_fallback\" \norder = 5\n\n[INTERPOLATED-LM]\n\n[TRAINING]\nscript = $moses-script-dir/training/train-model.perl\nalignment-heuristic = grow-diag-final-and\n\n[TUNING]\nraw-input = $myrk-data/dev.$input-extension\nraw-reference = $myrk-data/dev.$output-extension\n\n[EVALUATION:test]\ninput-sgm = /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.$input-extension.src.sgm\nreference-sgm = /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.$output-extension.ref.sgm\nCONFIG_EOF\necho 'config.baseline created!'")

add_md("## Step 6: Generate the Experiment Configs\nWe use `generate_configs.pl` to create the final config file for `my-ph`.")
add_code("%%bash\ncat << 'GEN_EOF' > /workspace/Kris/NLP/SMT/scripts/generate_configs.pl\n#!/usr/bin/perl\nuse strict;\nmy @langs;\nmy $smtpath = \"/workspace/Kris/NLP/SMT/pbsmt\";\n\nforeach my $trainFile ( </workspace/Kris/NLP/SMT/data/train.*> ) {\n    $trainFile =~ m/train\\.([a-z]+)/;\n    push @langs, $1;\n}\n\nforeach my $expt (qw/baseline/) {\n    die(\"$smtpath/$expt already exists! Delete it first.\") if (-d \"$smtpath/$expt\");\n    `mkdir -p $smtpath/$expt`;\n    foreach my $src (@langs) {\n        foreach my $trg (@langs) {\n            next if $src eq $trg;\n            my $pair = \"${src}-${trg}\";\n            my $configFile = \"$smtpath/$expt/$pair/config.${expt}.$pair\";\n            `mkdir -p $smtpath/$expt/$pair`;\n            open FILE, \">$configFile\" or die;\n            print FILE \"# Config file for $pair ($expt)\\n\\n[GENERAL]\\n\";\n            print FILE \"working-dir = $smtpath/$expt/$pair\\n\";\n            print FILE \"input-extension = ${src}\\noutput-extension = ${trg}\\npair-extension = ${pair}\\n\\n\";\n            close FILE;\n            \n            `cat $configFile /workspace/Kris/NLP/SMT/scripts/config.baseline > tmp`;\n            `mv tmp $configFile`;\n        }\n    }\n}\nGEN_EOF\n\ncd /workspace/Kris/NLP/SMT/scripts\nrm -rf /workspace/Kris/NLP/SMT/pbsmt/baseline\nperl generate_configs.pl\necho 'Configs generated successfully in pbsmt/baseline/!'")

add_md("## Step 7: Run the Baseline Pipeline!\nThis will kick off the Moses Experiment Management System and create the `steps` folder.")
add_code("%%bash\ncd /workspace/Kris/NLP/SMT/pbsmt/baseline/my-ph\n/workspace/Kris/NLP/SMT/mosesdecoder/scripts/ems/experiment.perl -config config.baseline.my-ph -exec -no-graph 2>&1 | tee -a run1.log")

with open("SMT_G2P_Clean.ipynb", "w") as f:
    json.dump(notebook, f, indent=2)

print("Notebook generated successfully!")
