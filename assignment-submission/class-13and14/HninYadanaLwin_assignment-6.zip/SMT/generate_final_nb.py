import json

notebook = {
    "cells": [],
    "metadata": {},
    "nbformat": 4,
    "nbformat_minor": 5
}

def add_md(text):
    notebook["cells"].append({
        "cell_type": "markdown",
        "metadata": {},
        "source": [line + "\n" for line in text.split("\n")]
    })

def add_code(text):
    notebook["cells"].append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [line + "\n" for line in text.split("\n")]
    })

add_md("# SMT Grapheme-to-Phoneme Pipeline\n\nThis notebook demonstrates a complete end-to-end Statistical Machine Translation (SMT) pipeline using Moses EMS. It translates graphemes (`.my`) to phonemes (`.ph`).")

add_md("## Step 1: Install Dependencies and Tools\nWe will install `fast_align`, a fast and modern word aligner that replaces the legacy GIZA++ to prevent segmentation faults on modern Linux distributions. We also install `libxml-twig-perl` for evaluation.")
add_code("%%bash\napt-get update\napt-get install -y cmake libxml-twig-perl\n\n# Compile fast_align\ncd /workspace/Kris/NLP/SMT\nif [ ! -d \"fast_align\" ]; then\n    git clone https://github.com/clab/fast_align.git\nfi\ncd fast_align\nmkdir -p build && cd build\ncmake ..\nmake\n\n# Copy tools to the binary directory\nmkdir -p /workspace/Kris/NLP/SMT/tools/\ncp fast_align /workspace/Kris/NLP/SMT/tools/\ncp atools /workspace/Kris/NLP/SMT/tools/\necho 'Dependencies successfully installed!'")

add_md("## Step 2: Prepare SGML Evaluation Data\nMoses EMS requires test data to be wrapped in SGML (XML-style) tags to properly score the translations at the end.")
add_code("%%bash\n# Create directory\nmkdir -p /workspace/Kris/NLP/SMT/pbsmt/test-sgm\n\n# Source SGM (test.my)\necho '<srcset setid=\"grapheme2phoneme_data\" srclang=\"any\">' > /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.my.src.sgm\necho '<doc docid=\"none\" genre=\"100\" origlang=\"my\">' >> /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.my.src.sgm\nawk '{print \"<seg id=\\\"\"NR\"\\\">\"$0\" </seg>\"}' /workspace/Kris/NLP/SMT/data/test.my >> /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.my.src.sgm\necho -e '</doc>\\n</srcset>' >> /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.my.src.sgm\n\n# Reference SGM (test.ph)\necho '<refset trglang=\"ph\" setid=\"grapheme2phoneme_data\" srclang=\"any\">' > /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.ph.ref.sgm\necho '<doc sysid=\"ref\" docid=\"none\" genre=\"100\" origlang=\"any\">' >> /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.ph.ref.sgm\nawk '{print \"<seg id=\\\"\"NR\"\\\">\"$0\" </seg>\"}' /workspace/Kris/NLP/SMT/data/test.ph >> /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.ph.ref.sgm\necho -e '</doc>\\n</refset>' >> /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.ph.ref.sgm\n\necho 'SGML files successfully generated!'")

add_md("## Step 3: All-in-One Experiment Playground\nThis script dynamically generates the Moses configuration based on the parameters you specify at the top. It then safely clears any old experiment data, executes the entire pipeline, and calculates your BLEU score. You can safely tweak the variables and rerun this cell as many times as you like.")
playground_code = """%%bash
# ==========================================
# ⚙️ EXPERIMENT PARAMETERS (Tweak these!)
# ==========================================
LM_ORDER=5                 # Language model order (Try 3, 4, 5, or 6. Do NOT exceed 6)
MAX_PHRASE_LENGTH=7        # Max phonemes to group (Try 5, 7, 9)
DISTORTION_LIMIT=0         # 0 forces strict monotonic translation. (Try 3 or 5 for slight reordering)
# ==========================================

echo "=== 1. Wiping old experiment data ==="
cd /workspace/Kris/NLP/SMT/pbsmt
rm -rf baseline

echo "=== 2. Generating new config with your parameters ==="
cat << CONFIG_EOF > config.baseline
input-extension = my
output-extension = ph

moses-src-dir = /workspace/Kris/NLP/SMT/mosesdecoder
moses-bin-dir = \\$moses-src-dir/bin
moses-script-dir = \\$moses-src-dir/scripts
external-bin-dir = /workspace/Kris/NLP/SMT/tools
myrk-data = /workspace/Kris/NLP/SMT/data

decoder = \\$moses-bin-dir/moses
lmplz = \\$moses-bin-dir/lmplz
lm-binarizer = \\$moses-bin-dir/build_binary
type = 8
generic-parallelizer = \\$moses-script-dir/ems/support/generic-parallelizer.perl

[CORPUS:myrk]
raw-stem = \\$myrk-data/train
max-sentence-length = 80

[LM:myrk]
raw-corpus = \\$myrk-data/train.\\$output-extension
lm-training = "\\$moses-script-dir/ems/support/lmplz-wrapper.perl -bin \\$moses-bin-dir/lmplz"
settings = "--prune '0 0 1' -T \\$working-dir/lm -S 20% --discount_fallback" 
order = ${LM_ORDER}

[INTERPOLATED-LM]
lm-binarizer = \\$moses-bin-dir/build_binary
type = 8

[TRAINING]
script = \\$moses-script-dir/training/train-model.perl
parallel = yes
alignment-symmetrization-method = grow-diag-final-and
lexicalized-reordering = msd-bidirectional-fe
max-phrase-length = ${MAX_PHRASE_LENGTH}
score-settings = "--GoodTuring"
fast-align-settings = "-d -o -v"

[TUNING]
tuning-script = \\$moses-script-dir/training/mert-moses.pl
tuning-settings = "-mertdir \\$moses-bin-dir"
raw-input = \\$myrk-data/dev.\\$input-extension
raw-reference = \\$myrk-data/dev.\\$output-extension
nbest = 100
filter-settings = ""
decoder-settings = "-dl ${DISTORTION_LIMIT}"

[EVALUATION]
decoder-settings = "-dl ${DISTORTION_LIMIT} -search-algorithm 1 -cube-pruning-pop-limit 5000 -s 5000"
wrapping-script = "\\$moses-script-dir/ems/support/wrap-xml.perl \\$output-extension"
nist-bleu = \\$moses-script-dir/generic/mteval-v13a.pl
nist-bleu-c = "\\$moses-script-dir/generic/mteval-v13a.pl -c"
analysis = \\$moses-script-dir/ems/support/analysis.perl
analyze-coverage = yes
report-segmentation = yes
report-precision-by-coverage = yes

[EVALUATION:test]
input-sgm = /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.\\$input-extension.src.sgm
reference-sgm = /workspace/Kris/NLP/SMT/pbsmt/test-sgm/test.\\$output-extension.ref.sgm
wrapping-frame = \\$input-sgm

[REPORTING]
CONFIG_EOF

echo "=== 3. Initializing folders ==="
# Provide a fresh generate script
cat << 'GEN_EOF' > generate_configs.pl
#!/usr/bin/perl
use strict;
my @langs;
my $smtpath = "/workspace/Kris/NLP/SMT/pbsmt";

foreach my $trainFile ( </workspace/Kris/NLP/SMT/data/train.*> ) {
    $trainFile =~ m/train\\.([a-z]+)/;
    push @langs, $1;
}

foreach my $expt (qw/baseline/) {
    `rm -rf $smtpath/$expt`;
    `mkdir -p $smtpath/$expt`;
    foreach my $src (@langs) {
        foreach my $trg (@langs) {
            next if $src eq $trg;
            my $pair = "${src}-${trg}";
            my $configFile = "$smtpath/$expt/$pair/config.${expt}.$pair";
            `mkdir -p $smtpath/$expt/$pair`;
            open FILE, ">$configFile" or die;
            print FILE "# Config file for $pair ($expt)\\n\\n[GENERAL]\\n";
            print FILE "working-dir = $smtpath/$expt/$pair\\n";
            print FILE "input-extension = ${src}\\noutput-extension = ${trg}\\npair-extension = ${pair}\\n\\n";
            close FILE;
            
            `cat $configFile /workspace/Kris/NLP/SMT/pbsmt/config.baseline > tmp`;
            `mv tmp $configFile`;
        }
    }
}
GEN_EOF

perl generate_configs.pl

echo "=== 4. Running Pipeline (This takes a few minutes...) ==="
cd /workspace/Kris/NLP/SMT/pbsmt/baseline/my-ph
/workspace/Kris/NLP/SMT/mosesdecoder/scripts/ems/experiment.perl \\
    -config config.baseline.my-ph \\
    -exec \\
    -no-graph > /dev/null 2>&1

echo "=== 5. FINAL BLEU SCORE ==="
LATEST_OUTPUT=$(ls -t /workspace/Kris/NLP/SMT/pbsmt/baseline/my-ph/evaluation/test.output* 2>/dev/null | head -1)
if [ -n "$LATEST_OUTPUT" ]; then
    /workspace/Kris/NLP/SMT/mosesdecoder/scripts/generic/multi-bleu.perl /workspace/Kris/NLP/SMT/data/test.ph < "$LATEST_OUTPUT"
else
    echo "CRASH: Could not find translation output."
fi
"""

add_code(playground_code)

with open("/Users/krislwin/Downloads/NLP_self-learning/SMT/SMT_G2P_Final_Assignment.ipynb", "w") as f:
    json.dump(notebook, f, indent=2)

print("Notebook SMT_G2P_Final_Assignment.ipynb updated successfully!")
