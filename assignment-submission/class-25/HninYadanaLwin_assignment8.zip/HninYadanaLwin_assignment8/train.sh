#!/bin/bash
#SBATCH -p gpu
#SBATCH -N 1
#SBATCH -c 16
#SBATCH --gpus=1
#SBATCH -t 120:00:00
#SBATCH -A lt200246
#SBATCH -J MSL_Video_Recognition

set -e

module purge
module load Mamba

#export PYTHONNOUSERSITE=1
export PYTHON="/home/hlwin/.conda/envs/LM_mp310/bin/python"

cd /project/lt200246-mmacma/Kris/MSL/msl_recognition

$PYTHON -c "import sys; print(sys.executable)"
# RUN STAGE 3 (Augmentation) AND THEN STAGE 4 (Training)
$PYTHON train.py --stages 4 5
