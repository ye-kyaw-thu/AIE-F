# Neural Machine Translation with Bayesian Hyperparameter Optimization
## Phoneme-to-Grapheme Translation (Pali → Myanmar Script)

**Course:** Natural Language Processing  
**Student:** [Your Name]  
**Date:** August 2026  
**Tool:** Marian NMT (pymarian), Optuna  
**Task:** Phoneme-to-Grapheme (PH → MY) Translation

---

## 1. Introduction

Neural Machine Translation (NMT) has become the dominant approach for sequence-to-sequence language conversion tasks. In this assignment, we apply NMT to a Phoneme-to-Grapheme (PH→MY) conversion task, translating Pali phoneme sequences into Myanmar script (graphemes). Two NMT architectures are investigated:

1. **Sequence-to-Sequence (Seq2Seq)** — an LSTM-based encoder-decoder model
2. **Transformer** — an attention-based model with multi-head self-attention layers

A key challenge in NMT is selecting good hyperparameters (learning rate, dropout, number of layers, embedding dimensions, etc.). Manual tuning is time-consuming and unreliable. This assignment therefore applies **Bayesian Optimization** using the Optuna framework to automatically search for optimal hyperparameters for both architectures.

Additionally, **pseudo-labeling** is applied as a data augmentation technique during the Bayesian optimization training to explore its effect on model quality.

---

## 2. Dataset

The dataset consists of parallel Pali phoneme–Myanmar grapheme pairs:

| Split | Sentences | Description |
|-------|-----------|-------------|
| Train | 22,000    | Used for model training |
| Dev   | 2,000     | Used for validation and early stopping |
| Test  | 2,802     | Used for final BLEU evaluation |

**Vocabulary:**
- Source (Phoneme): Built with `pymarian vocab` from the training set (Pali phoneme tokens such as `te'`, `pjaun`, `ka'`, etc.)
- Target (Grapheme): Built from Myanmar script syllables (e.g., `တက်`, `ပြောင်`, `ကပ်`, etc.)

---

## 3. Baseline Models (Original Training)

Before Bayesian optimization, both architectures were trained with fixed, manually selected hyperparameters as a baseline.

### 3.1 Baseline Seq2Seq (LSTM)
- Architecture: Encoder-Decoder with LSTM cells
- Training iterations: 60,000
- **Baseline BLEU: 77.92** (1-gram: 88.0, 2-gram: 79.7, 3-gram: 75.0, 4-gram: 70.2)

### 3.2 Baseline Transformer
- Architecture: Multi-head self-attention transformer
- Training iterations: 55,000
- **Baseline BLEU: 76.84** (1-gram: 87.6, 2-gram: 78.7, 3-gram: 73.3, 4-gram: 69.2)

---

## 4. Bayesian Hyperparameter Optimization

### 4.1 Methodology

Bayesian optimization is a sequential model-based optimization technique. Unlike grid search or random search, it builds a probabilistic surrogate model (typically a Gaussian Process) of the objective function and uses it to decide which hyperparameter values to evaluate next. This leads to finding good hyperparameters with fewer trials.

**Framework Used:** [Optuna](https://optuna.org/) — a state-of-the-art hyperparameter optimization library.

**Objective Function:** Each trial trains a model for a fixed number of iterations and evaluates validation BLEU score. The study **maximizes** the BLEU score.

**Sampler:** Optuna's default Tree-structured Parzen Estimator (TPE), which models the distribution of good vs. bad hyperparameters and samples from the promising region.

### 4.2 Search Space

#### Seq2Seq (LSTM) Hyperparameter Search Space

| Hyperparameter | Range | Type |
|----------------|-------|------|
| Learning Rate (`lr`) | [1e-4, 1e-3] (log-scale) | Float |
| LSTM Dropout (`dropout_lstm`) | [0.1, 0.3] | Float |
| Source Dropout (`dropout_src`) | [0.1, 0.3] | Float |
| Encoder Depth (`enc_depth`) | {1, 2} | Integer |
| Embedding Dimension (`dim_emb`) | {64, 128} | Categorical |
| LSTM Hidden Dimension (`dim_lstm`) | {128, 256} | Categorical |

#### Transformer Hyperparameter Search Space

| Hyperparameter | Range | Type |
|----------------|-------|------|
| Learning Rate (`lr`) | [1e-4, 1e-3] (log-scale) | Float |
| Transformer Dropout (`transformer_dropout`) | [0.1, 0.3] | Float |
| Encoder Depth (`enc_depth`) | [1, 4] | Integer |
| Decoder Depth (`dec_depth`) | [1, 4] | Integer |
| Attention Heads (`transformer_heads`) | {2, 4, 8} | Categorical |

### 4.3 Results — Best Trials Found

#### Seq2Seq Best Trial (Trial #13)

| Hyperparameter | Optimized Value |
|----------------|-----------------|
| Learning Rate | 0.000354 |
| LSTM Dropout | 0.1499 |
| Source Dropout | 0.1009 |
| Encoder Depth | 1 |
| Embedding Dimension | 128 |
| LSTM Hidden Dimension | 128 |
| **Best BLEU (Validation)** | **75.23** |

**Test Set BLEU: 73.49** (1-gram: 85.7, 2-gram: 75.4, 3-gram: 69.3, 4-gram: 65.1)

#### Transformer Best Trial (Trial #12)

| Hyperparameter | Optimized Value |
|----------------|-----------------|
| Learning Rate | 0.0001027 |
| Transformer Dropout | 0.1638 |
| Encoder Depth | 3 |
| Decoder Depth | 4 |
| Attention Heads | 8 |
| **Best BLEU (Validation)** | **77.32** |

**Test Set BLEU: 77.96** (1-gram: 87.9, 2-gram: 79.0, 3-gram: 74.2, 4-gram: 71.9)

---

## 5. Pseudo-Labeling for Data Augmentation

### 5.1 What is Pseudo-Labeling?

Pseudo-labeling is a semi-supervised data augmentation technique. A trained model is used to generate predictions (pseudo labels) for unlabeled or existing source data. These machine-generated translations are then combined with the original training data to expand the dataset size and improve generalization.

### 5.2 Implementation

In this assignment, the Seq2Seq Bayesian model (Trial #0) was used to generate pseudo-labeled translations:

1. **Load** the trained Seq2Seq model from `model_trial_0`
2. **Translate** the training source (`train.ph`) to generate `train.my_pseudo`
3. **Combine** the pseudo-labeled pairs with real training pairs
4. **Retrain** the model on the augmented dataset during the Bayesian optimization loop

```python
# Pseudo-labeling pipeline
mt = Translator(models=model_path, vocabs=[vocab_ph, vocab_my], devices=[0])
with open('data/train.ph') as f:
    src_lines = [line.strip() for line in f]

all_hyp_lines = []
for i in range(0, len(src_lines), batch_size):
    batch = src_lines[i:i+batch_size]
    hyp_batch = mt.translate(batch)
    all_hyp_lines.extend(hyp_batch)

# Save pseudo-labeled target
with open('data/train.my_pseudo', 'w') as f:
    for line in all_hyp_lines:
        f.write(line + '\n')
```

This augmented training data was used in subsequent Bayesian optimization trials for the Seq2Seq model.

---

## 6. Comparison of Results

| Model | Configuration | BLEU Score | 1-gram | 2-gram | 3-gram | 4-gram |
|-------|--------------|-----------|--------|--------|--------|--------|
| Seq2Seq | Baseline (manual params) | **77.92** | 88.0 | 79.7 | 75.0 | 70.2 |
| Seq2Seq | Bayesian Optimized + Pseudo-labeling | 73.49 | 85.7 | 75.4 | 69.3 | 65.1 |
| Transformer | Baseline (manual params) | 76.84 | 87.6 | 78.7 | 73.3 | 69.2 |
| Transformer | Bayesian Optimized | **77.96** | 87.9 | 79.0 | 74.2 | 71.9 |

---

## 7. Analysis and Discussion

### 7.1 Transformer: Bayesian Optimization Improved Performance

For the Transformer architecture, Bayesian optimization successfully found better hyperparameters. The optimized model achieved **BLEU 77.96**, which is an improvement of **+1.12 BLEU points** over the baseline (76.84). Notably, the optimized configuration used a deep architecture (3 encoder layers, 4 decoder layers, 8 attention heads) with a low learning rate (0.0001027) and moderate dropout (0.1638), which is consistent with best practices for transformer NMT.

### 7.2 Seq2Seq: Bayesian Optimization Did Not Improve Results

For the Seq2Seq architecture, the Bayesian-optimized model scored **BLEU 73.49**, which is **lower** than the baseline (77.92). Several factors may explain this:

1. **Limited Search Budget:** Bayesian optimization with a limited number of trials (13 total) may not have fully explored the search space for LSTM-based models, which tend to be more sensitive to hyperparameter choices.
2. **Pseudo-labeling Noise:** The pseudo-labeled training data was generated by an earlier model (Trial #0), which may not have been accurate enough. Noisy pseudo-labels can hurt model quality rather than help.
3. **Architecture Constraints:** The shallow encoder depth (1 layer) and smaller embedding dimension (128) found by Optuna may not have been sufficient for this task.
4. **Early Stopping:** LSTM models trained with early stopping based on validation BLEU sometimes converge to different local optima depending on initialization, making it harder for Bayesian optimization to find consistent improvements.

### 7.3 Architectural Comparison

The Transformer consistently benefits from deeper architectures and multi-head attention, which aligns with the literature showing Transformers outperforming LSTM-based models for sequence tasks. The best Transformer (BLEU 77.96) slightly outperforms the best Seq2Seq baseline (77.92), reinforcing this finding.

### 7.4 Effect of Pseudo-Labeling

While pseudo-labeling is a widely used technique, its effectiveness depends on the quality of the initial model. In this case, using early-stage model predictions as pseudo-labels introduced noise that reduced generalization. Future work could:
- Use a higher-quality model to generate pseudo-labels
- Apply confidence filtering (only keep high-confidence pseudo-labels)
- Use back-translation instead of self-training pseudo-labels

---

## 8. Conclusion

This assignment demonstrated the application of Bayesian hyperparameter optimization using Optuna for NMT training in both Seq2Seq (LSTM) and Transformer architectures on the Pali phoneme to Myanmar grapheme translation task.

**Key findings:**
- Bayesian optimization **improved the Transformer model** by +1.12 BLEU (76.84 → 77.96)
- Bayesian optimization with pseudo-labeling **did not improve the Seq2Seq model** (77.92 → 73.49), likely due to noisy pseudo-labels and insufficient search trials
- The **Transformer architecture** benefited most from optimization, achieving the highest overall BLEU score of **77.96**
- **Pseudo-labeling** requires careful quality control to be effective; using low-quality pseudo-labels can degrade performance

Bayesian optimization is a principled and efficient method for hyperparameter search, outperforming manual or random search in terms of sample efficiency. However, the number of trials, data quality, and model architecture all significantly impact the optimization outcome.

---

## 9. References

1. Bergstra, J., & Bengio, Y. (2012). Random search for hyper-parameter optimization. *JMLR*, 13, 281–305.
2. Snoek, J., Larochelle, H., & Adams, R. P. (2012). Practical Bayesian optimization of machine learning algorithms. *NeurIPS*.
3. Akiba, T., et al. (2019). Optuna: A next-generation hyperparameter optimization framework. *KDD*.
4. Vaswani, A., et al. (2017). Attention is all you need. *NeurIPS*.
5. Junczys-Dowmunt, M., et al. (2018). Marian: Fast Neural Machine Translation in C++. *ACL*.
6. Lee, D. H. (2013). Pseudo-label: The simple and efficient semi-supervised learning method for deep neural networks. *ICML Workshop*.

---

*Implemented using: Python 3.12, pymarian (Marian NMT v1.12.42), Optuna 4.9.0*
