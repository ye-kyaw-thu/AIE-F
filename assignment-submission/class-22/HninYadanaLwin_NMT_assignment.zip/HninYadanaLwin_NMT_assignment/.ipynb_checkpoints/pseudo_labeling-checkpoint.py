import time
from pymarian import Translator

start_time = time.time()

model_path = "/workspace/Kris/NLP/NMT/model_seq2seq_bayesian/model_trial_0/model.iter80000.npz"
vocab_ph = "/workspace/Kris/NLP/NMT/data/vocab/vocab.ph.yml"  # SOURCE Vocab
vocab_my = "/workspace/Kris/NLP/NMT/data/vocab/vocab.my.yml"  # TARGET Vocab

print("Loading Forward Translator...")
mt = Translator(
    models=model_path,
    vocabs=[vocab_ph, vocab_my], 
    devices=[0],
    quiet=True,
    quiet_translation=True
)

input_file = '/workspace/Kris/NLP/NMT/data/train.ph'
print(f"Reading phonemes from {input_file}...")

with open(input_file, 'r', encoding='utf-8') as f:
    src_lines = [line.strip() for line in f]

batch_size = 64
all_hyp_lines = []

print(f"Translating {len(src_lines)} lines to Graphemes...")

for i in range(0, len(src_lines), batch_size):
    batch = src_lines[i : i + batch_size]
    
    safe_batch = [text if text else "a" for text in batch]
    hyp_batch = mt.translate(safe_batch)

    for j, original_text in enumerate(batch):
        if not original_text:
            hyp_batch[j] = ""
            
    all_hyp_lines.extend(hyp_batch)

output_file = '/workspace/Kris/NLP/NMT/data/train.my_pseudo'
with open(output_file, 'w', encoding='utf-8') as f:
    for line in all_hyp_lines:
        f.write(line + '\n')

print(f"Finished in {time.time() - start_time:.2f}s.")
print(f"Success! Open {output_file} to verify it now contains Myanmar script.")